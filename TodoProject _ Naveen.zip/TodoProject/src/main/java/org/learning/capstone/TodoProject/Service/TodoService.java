package org.learning.capstone.TodoProject.Service;

import java.time.LocalDateTime;
import java.util.List;

import org.learning.capstone.TodoProject.Entity.Todo;
import org.learning.capstone.TodoProject.Repository.TodoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class TodoService{

	@Autowired
	TodoRepository todoRepository;

	public List<Todo> fetchAllTodo() {
		return todoRepository.findAll();
		
	}

	public boolean saveUser(Todo todo) {
		// TODO Auto-generated method stub
		if(todoRepository.existsById(todo.id))
			return false;
		todo.setCreatedAt(LocalDateTime.now());
		todoRepository.save(todo);
		return true;
	}

	public Todo getUser(int id) {
		// TODO Auto-generated method stub
		
		return todoRepository.findById(id).orElse(null);
	
	}

	public boolean updateDetails(int id, Todo todo) {
		// TODO Auto-generated method stub
		if(!todoRepository.existsById(id))
			return false;
		todoRepository.save(todo);
		return true;
	}

	public boolean updateStatusDetails(int id) {
		// TODO Auto-generated method stub
		if(!todoRepository.existsById(id))
			return false;
		
		Todo todo=todoRepository.findById(id).orElse(null);
		todo.setCompleted("Completed");
		todoRepository.save(todo);
		return true;
	}

	public boolean deleteDetails(int id) {
		// TODO Auto-generated method stub
		if(!todoRepository.existsById(id))
			return false;
		todoRepository.deleteById(id);
		return true;
	}

	public long countofTodos() {
		// TODO Auto-generated method stub
		
		return todoRepository.count();
	}
	
}
