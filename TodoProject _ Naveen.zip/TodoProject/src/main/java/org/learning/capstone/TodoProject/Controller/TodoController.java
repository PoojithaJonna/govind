package org.learning.capstone.TodoProject.Controller;

import java.util.List;

import org.learning.capstone.TodoProject.Entity.Todo;
import org.learning.capstone.TodoProject.Service.TodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TodoController {
	
	@Autowired
	TodoService todoService;
	
	@GetMapping(path="/")
	public ResponseEntity<String> helloWorld(){
		return ResponseEntity.ok("Hello World");
	}
	
	@GetMapping(path="/todos")
	public ResponseEntity<List<Todo>> FetchTodos(){
		List<Todo> todo=todoService.fetchAllTodo();
		return ResponseEntity.ok().body(todo);	
	}
	@PostMapping(path="/todos")
	public ResponseEntity<String> createTodo(@RequestBody Todo todo){
		boolean status=todoService.saveUser(todo);
		if(!status)
			return ResponseEntity.status(409).body("id is already exists");
		return ResponseEntity.ok("Success");
	}
	@GetMapping(path="/todos/{id}")
	public ResponseEntity<Todo> fetchTodo(@PathVariable("id") int id){
		Todo todo=todoService.getUser(id);
		if(todo==null)
			return ResponseEntity.status(404).body(null);
		return ResponseEntity.ok().body(todo);
	}
	@PutMapping(path="/todos/{id}")
	public ResponseEntity<String> updateTodo(@PathVariable("id") int id,@RequestBody Todo todo){
		boolean status=todoService.updateDetails(id,todo);
		if(!status)
			return ResponseEntity.status(404).body("id is not present");
		return ResponseEntity.ok("Success");
	}
	@PatchMapping(path="/todos/{id}")
	public ResponseEntity<String> updateStatusTodo(@PathVariable("id") int id){
		boolean status=todoService.updateStatusDetails(id);
		if(!status)
			return ResponseEntity.status(404).body("id is not present");
		return ResponseEntity.ok("Success");
	}
	@DeleteMapping(path="/todos/{id}")
	public ResponseEntity<String> deleteTodo(@PathVariable("id") int id){
		boolean status=todoService.deleteDetails(id);
		if(!status)
			return ResponseEntity.status(404).body("id is not present");
		return ResponseEntity.ok("Success");
	}
	@GetMapping(path="/todos/count")
	public ResponseEntity<String> countTodo(){
		long count=todoService.countofTodos();
		return ResponseEntity.ok("Todo count is "+count);
	}
}
