package com.application.TodoApp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class Test {

	public static Gson gson;
	public static void main(String[] args) throws ParseException {
		Date date = new Date();
		SimpleDateFormat sdf2 =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		gson = new GsonBuilder().setDateFormat(sdf2.toPattern()).create();
		String dateString = gson.toJson(date); 
		System.out.println("Time Stamp Came from Producer: "+dateString);
		SimpleDateFormat sdf1 = new SimpleDateFormat("MMM dd, yyyy, h:mm:ss a");
		dateString = dateString.replace("\"", "");
		System.out.println("\nTime Stamp At consumer after removing extra quotes: "+dateString);
		Date date2 = sdf2.parse(dateString);
		System.out.println("\nTime Stamp At Consumer After Parsing to Original Format: " + gson.toJson(date2));
		String formattedDate = sdf2.format(date2);
		System.out.println("\nFinal Formatted Date going to DB: "+formattedDate);
		
		

	}

}
