package com.application.TodoApp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.TodoApp.Repo.TodoRepo;
import com.application.TodoApp.entity.Todo;


public interface TodoService {

	Todo saveTodo(Todo todo);

	List<Todo> getAllTodos();

	Todo getTodoById(int id);

	Todo updateTodoById(Todo todo, int id);

	Todo updateCompleted(Boolean completed, int id);

	void deletedById(int id);

	Integer getCount();

}
